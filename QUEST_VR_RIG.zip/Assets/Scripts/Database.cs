using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Database {
    // Start is called before the first frame update

    public class Item {
        public string text = "Untiteled";
        public int matId = 0;
     //   public int textMatId = 0; basis voor het bepalen van een tekst kleur (dit is echter zeer complex)
    }

    public static Dictionary<int, Item> data = new Dictionary<int, Item> {
        {1, new Item{text="Danken", matId=0} },
        {2, new Item{text="Dansen", matId=0} },
        {3, new Item{text="Delen", matId=0} },
        {4, new Item{text="Denken", matId = 0} },
        {5, new Item{text="Dichten", matId=0} },
        {6, new Item{text="Dromen", matId=0} },
        {7, new Item{text="Durven", matId=0} },
        {8, new Item{text="Empathize", matId = 1} },
        {9, new Item{text="Define", matId = 1} },
        {10, new Item{text="Ideate", matId = 1} },
        {11, new Item{text="Prototype", matId = 1} },
        {12, new Item{text="Testen", matId = 1} },
        {13, new Item{text="Implementing", matId = 1} },
        {14, new Item{text="A/B Testing", matId = 2} },
        {15, new Item{text="Benchmark creation", matId = 2} },
        {16, new Item{text="Best,good & bad practices", matId = 2} },
        {17, new Item{text="Business Model Canvas", matId = 2} },
        {18, new Item{text="Co-creaton", matId = 2} },
        {19, new Item{text="Co-reflection", matId = 2} },
        {20, new Item{text="Comparison Chart", matId = 2} },
        {21, new Item{text="Competitive analysis", matId = 2} },
        {22, new Item{text="Concept", matId = 2} },
        {23, new Item{text="Cultural probes", matId = 2} },
        {24, new Item{text="Customer Journey", matId = 2} },
        {25, new Item{text="Expert Interview", matId = 2} },
        {26, new Item{text="Field trail", matId = 2} },
        {27, new Item{text="Sketching", matId = 2} },
        {28, new Item{text="Literature Study", matId = 2} },
        {29, new Item{text="Thinking aloud", matId = 2} },
        {30, new Item{text="Usability Testing", matId = 2} },
    };

}

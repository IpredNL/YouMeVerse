using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnInfo : MonoBehaviour
{
    public int hexIndex;

    void Start() {

        string word = "HexIndex";
        int _material = 0;
        if (Database.data.TryGetValue(hexIndex, out Database.Item item)) {
            word = item.text;
            _material = item.matId;
        }
        gameObject.GetComponent<SpawnHex>().SetText(word);
        gameObject.GetComponent<SpawnHex>().SetMaterial(_material);
    }
}

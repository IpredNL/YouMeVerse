using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HexaWorld : MonoBehaviour
{
    // Start is called before the first frame update
    private Vector3 spawnPosition;
    public HexManager _hexManager;
    public int KernNummer;
    private int DesignNummer;
    private int MethodeNummer;
    private bool ActiveKern;
    private bool ActiveDesign;
    private bool ActiveMethode;
    void Start()
    {
        float sca = 10;


        MakeHexa(0*sca, 0*sca, 0, 107);
        MakeHexa(1*sca, 0*sca,10, 101);
        MakeHexa(1*sca, 1*sca, 30, 102);
        MakeHexa(-1 * sca, 1 * sca, 50, 103);
        MakeHexa(2 * sca, 0 * sca, 60, 104);
        MakeHexa(2 * sca, 0 * sca, 70, 105);
        MakeHexa(2 * sca, 1 * sca, 80, 106);
        MakeHexa(-2 * sca, 1 * sca, 90, 107);
    }


    void MakeHexa(float xPos, float yPos, float Rotation, int hexaId) {
        spawnPosition.x = xPos;
        spawnPosition.y = 0.1f;
        spawnPosition.z = yPos; // is nu Z ivm vector 3 anders is Y omhoog.
        hexaId--;
        Debug.Log(hexaId);
        if (hexaId >100 && hexaId <200) {
                KernNummer = hexaId - 100;
                ActiveKern = true;
            GameObject instance = Instantiate(_hexManager.KernwaardeHex[KernNummer], spawnPosition, Quaternion.Euler(new Vector3(90, Rotation, 0)));
        } else if (hexaId > 50 && hexaId < 100) { //Design thinking methode
            DesignNummer = hexaId - 50;
                ActiveDesign = true;
            GameObject instance = Instantiate(_hexManager.DesignThinkingHex[DesignNummer], spawnPosition, Quaternion.Euler(new Vector3(90, Rotation, 0)));
        } else if (hexaId > 200 && hexaId < 300) { // Methode kaarten
            MethodeNummer = hexaId - 200;
                ActiveMethode = true;
            GameObject instance = Instantiate(_hexManager.MethodeHex[MethodeNummer], spawnPosition, Quaternion.Euler(new Vector3(90, Rotation, 0)));
        }
    }
}

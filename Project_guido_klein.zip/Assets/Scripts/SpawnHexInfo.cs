using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnHexInfo : MonoBehaviour
{
    public int SpawnHexNummer;
    public HexManager _hexManager;
    public SelectDetect _selectDetect;
    public bool DebugThis;
    public int DebugNummer;
    public List<GameObject> SpawnedHex;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void spawnNewKernHex(int kernNummer) {
        DebugNummer = kernNummer;
        DebugThis = true;
         GameObject instance = Instantiate(_hexManager.KernwaardeHex[kernNummer-1],transform.position, Quaternion.Euler(new Vector3(90, 0, 90))); //orgineel was 90,0,90 voor socketsnap
        instance.transform.parent = transform;
    }
    public void spawnNewDesignHex(int designNummer) {
            GameObject instance = Instantiate(_hexManager.DesignThinkingHex[designNummer-1],transform.position, Quaternion.Euler(new Vector3(90, 0, 90)));
        instance.transform.parent = transform;
    }
    public void spawnNewMethodeHex(int methodeNummer) {
        GameObject instance = Instantiate(_hexManager.MethodeHex[methodeNummer-1], transform.position, Quaternion.Euler(new Vector3(90, 0, 90)));
        instance.transform.parent = transform;
    }
    public void DestroyHex() {
        foreach (Transform child in transform) {
            child.gameObject.SetActive(false);
        }
    }

}
